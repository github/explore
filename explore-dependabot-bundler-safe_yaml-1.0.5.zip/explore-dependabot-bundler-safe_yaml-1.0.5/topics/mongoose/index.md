---
aliases: mongoosejs, mongoose-js, mongoose-plugin, mongoose-model
created_by: LearnBoost
display_name: Mongoose
github_url: https://github.com/Automattic/mongoose
logo: mongoose.png
released: 2010
related: mongodb, nodejs, orm, odm
short_description: Mongoose is a MongoDB object modeling tool designed to work in an asynchronous environment.
topic: mongoose
url: http://mongoosejs.com
---
Mongoose is a MongoDB object modeling tool designed to work in an asynchronous environment. Mongoose includes built-in type casting, validation, query building, and business logic hooks.
