---
created_by: Digital Ocean and GitHub
display_name: Hacktoberfest
logo: hacktoberfest.png
released: October 2014
short_description: Hacktoberfest is a month-long celebration of open source software.
topic: hacktoberfest
url: https://hacktoberfest.digitalocean.com/
---
Hacktoberfest is a month-long celebration of open source software. Each October, open source maintainers give new contributors extra attention as they guide developers through their first pull requests on GitHub.
