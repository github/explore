---
created_by: Bram Moolenaar
display_name: Vim
github_url: https://github.com/vim/vim
logo: vim.png
released: November 2, 1991
short_description: Vim is a console-run text editor program.
topic: vim
related: emacs
url: http://www.vim.org/download.php
wikipedia_url: https://en.wikipedia.org/wiki/Vim_(text_editor)
---
Vim is a highly customizable text editor that can run in a shell. Bram Moolenaar is credited with the development of Vim, which he began in 1988.
