---
aliases: mysql-database
created_by: David Axmark, Allan Larsson and Michael "Monty" Widenius
display_name: MySQL
github_url: https://github.com/mysql
logo: mysql.png
released: May 23, 1995
short_description: MySQL is an open source relational database management system.
topic: mysql
url: https://www.mysql.com/
wikipedia_url: https://en.wikipedia.org/wiki/MySQL
---
MySQL is an open source relational database management system.  Based in Structured Query Language (SQL), MySQL can run on most platforms and is mainly used for web-based applications. It is written in C and C++.
