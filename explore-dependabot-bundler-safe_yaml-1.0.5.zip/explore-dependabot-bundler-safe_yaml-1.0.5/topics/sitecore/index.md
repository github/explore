---
aliases: xdb
created_by: Michael Seifert, Ole Sas Thrane, and Jakob Christensen
display_name: Sitecore
github_url: https://github.com/sitecore
logo: sitecore.png
related: adobe, acquia, oracle, episerver, ibm
released: 2001
short_description: Robust content management that scales for enterprise needs.
topic: sitecore
url: https://sitecore.net
wikipedia_url: https://en.wikipedia.org/wiki/Sitecore
---
Sitecore is a customer experience management company that provides web content management and multichannel marketing automation software.
