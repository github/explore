---
aliases: gml, gamemaker-language, game-maker-language, gamemaker-studio, gamemaker-studio-2, gms2
created_by: Mark Overmars
display_name: GameMaker Studio
logo: gamemaker.png
released: November 5, 1999
short_description: GameMaker Studio is an accessible cross-platform 2D game engine.
topic: gamemaker
url: https://www.yoyogames.com/gamemaker
wikipedia_url: https://en.wikipedia.org/wiki/GameMaker_Studio
---
GameMaker Studio is a cross-platform game engine developed by YoYo Games. It is primarily used to make 2D games via a drag-and-drop visual programming language or a scripting language known as Game Maker Language.
