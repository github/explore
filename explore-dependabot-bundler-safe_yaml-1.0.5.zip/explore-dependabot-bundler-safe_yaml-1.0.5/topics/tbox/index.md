---
created_by: ruki
display_name: tbox
github_url: https://github.com/tboox/tbox
logo: tbox.png
released: August 15, 2010
short_description: TBOX is a glib-like cross-platform C library that is simple to use yet powerful in nature.
topic: tbox
url: http://tboox.org/
---
TBOX is a glib-like cross-platform C library that is simple yet powerful. It focuses on making C development easier and provides many modules, so that any developer can quickly pick it up and enjoy the productivity boost when developing in the C language.

