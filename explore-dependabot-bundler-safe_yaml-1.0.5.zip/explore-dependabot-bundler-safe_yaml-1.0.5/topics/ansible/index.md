---
created_by: Michael DeHaan
display_name: Ansible
github_url: https://github.com/ansible
logo: ansible.png
released: February 20, 2012
short_description: Ansible is a simple and powerful automation engine.
topic: ansible
url: https://www.ansible.com/
wikipedia_url: https://en.wikipedia.org/wiki/Ansible_(software)
---
Ansible is a simple and powerful automation engine. It is used to help with configuration management, application deployment, and task automation.
