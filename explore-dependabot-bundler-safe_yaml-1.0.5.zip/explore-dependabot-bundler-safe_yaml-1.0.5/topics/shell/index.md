---
aliases: shell-script, shell-scripts, shellscript, shellcode
created_by: Glenda Schroeder
display_name: Shell
related: bash
released: '1965'
short_description: A shell is a command-line tool, designed to be run by the Unix
  shell.
topic: shell
wikipedia_url: https://en.wikipedia.org/wiki/Shell_script
---
A shell is a text-based terminal, used for manipulating programs and files. Shell scripts typically manage program execution.
