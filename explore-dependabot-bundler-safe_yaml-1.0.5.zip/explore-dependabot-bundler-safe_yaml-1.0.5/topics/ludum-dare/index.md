---
display_name: Ludum Dare
created_by: Geoff Howland
github_url: https://github.com/ludumdare
aliases: ludumdare, ldjam, ld0, ldjam0, ld1, ldjam1, ld2, ldjam2, ld3, ldjam3, ld4, ldjam4, ld5, ldjam5, ld6, ldjam6, ld7, ldjam7, ld8, ldjam8, ld9, ldjam9, ld10, ldjam10, ld11, ldjam11, ld12, ldjam12, ld13, ldjam13, ld14, ldjam14, ld15, ldjam15, ld16, ldjam16, ld17, ldjam17, ld18, ldjam18, ld19, ldjam19, ld20, ldjam20, ld21, ldjam21, ld22, ldjam22, ld23, ldjam23, ld24, ldjam24, ld25, ldjam25, ld26, ldjam26, ld27, ldjam27, ld28, ldjam28, ld29, ldjam29, ld30, ldjam30, ld31, ldjam31, ld32, ldjam32, ld33, ldjam33, ld34, ldjam34, ld35, ldjam35, ld36, ldjam36, ld37, ldjam37, ld38, ldjam38, ld39, ldjam39, ld40, ldjam40, ld41, ldjam41, ld42, ldjam42, ld43, ldjam43, ld44, ldjam44, ld45, ldjam45, ld46, ldjam46, ld47, ldjam47, ld48, ldjam48, ld49, ldjam49
related: global-game-jam, game-off
logo: ludum-dare.png
short_description: Ludum Dare is one of the world's largest and longest running Game Jam events.
topic: ludum-dare
url: http://ldjam.com/
wikipedia_url: https://en.wikipedia.org/wiki/Ludum_Dare
---
Ludum Dare is an online community best known for “Ludum Dare”, the Accelerated Game Development Event of the same name (also called a “Game Jam”). During a Ludum Dare, developers from around the world spend a weekend creating games based on a theme suggested by the community. Ludum Dare events take place every April, August and December.
