---
topic: fish
aliases: fish-shell, fishshell, fish-plugin, fish-packages, fisherman, fisher, oh-my-fish
created_by: Axel Liljencrantz & ridiculousfish
display_name: friendly interactive shell
github_url: https://github.com/fish-shell/fish-shell
logo: fish.png
related: bash, zsh
released: February 13, 2005
short_description: The user-friendly command line shell.
url: https://fishshell.com
wikipedia_url: https://en.wikipedia.org/wiki/friendly_interactive_shell
# From the homepage:
---
fish is a smart and user-friendly command line shell for Linux, macOS, and the rest of the family.
