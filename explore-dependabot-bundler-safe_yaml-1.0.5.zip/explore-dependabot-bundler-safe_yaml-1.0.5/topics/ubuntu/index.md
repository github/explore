---
aliases: kubuntu, xubuntu, lubuntu, edubuntu, ubuntu1604, ubuntu1404, ubuntu1704, ubuntu1204, ubuntu-core
created_by: Canonical Ltd., Ubuntu community
display_name: Ubuntu
github_url: https://github.com/ubuntu
logo: ubuntu.png
released: October 2004
short_description: Ubuntu is a Linux-based operating system.
topic: ubuntu
url: https://www.ubuntu.com/
wikipedia_url: https://en.wikipedia.org/wiki/Ubuntu_(operating_system)
---
Ubuntu builds upon Debian's architecture to provide a Linux server and desktop operating system. Ubuntu prioritizes security, as the majority of its network ports are closed by default.
