---
aliases: monero-cryptocurrency, monero-crypto
created_by: Monero
display_name: Monero
github_url: https://github.com/monero-project
logo: monero.png
released: April 18, 2014
short_description: Monero is a private, fungible, open source, decentralized cryptocurrency.
topic: monero
url: https://getmonero.org/
wikipedia_url: https://en.wikipedia.org/wiki/Monero_(cryptocurrency)
---
Monero is a cryptocurrency focused on privacy, decentralization and scalability. Unlike many cryptocurrencies, Monero is based on CryptoNote protocol and possesses significant algorithmic differences relating to blockchain obfuscation.
