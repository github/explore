---
aliases: virtual-reality-experiences, virtual-reality-worlds, vr
display_name: Virtual reality
short_description: Virtual reality is an artificial environment displayed through
  digital means.
topic: virtual-reality
wikipedia_url: https://en.wikipedia.org/wiki/Virtual_reality
---
Virtual reality is a fully immersive and interactive computer-simulated environment. Currently, the most popular display option is through a VR headset.
