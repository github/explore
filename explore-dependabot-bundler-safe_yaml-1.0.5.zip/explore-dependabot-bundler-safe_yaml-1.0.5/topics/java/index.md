---
aliases: java-8, java8
created_by: James Gosling
display_name: Java
logo: java.png
released: May 23, 1995
short_description: Java is an object-oriented programming language used mainly for
  desktop and mobile applications.
topic: java
url: https://www.java.com/en/
wikipedia_url: https://en.wikipedia.org/wiki/Java_(software_platform)
---
Java was originally developed as an alternative to the C/C++ programming languages. It is now mainly used for building desktop, Android, and web server applications. Java is owned and licensed through Oracle.
