---
aliases: identity, id-as-a-service, idaas
created_by: Eugenio Pace and Matías Woloski
display_name: Auth0
github_url: https://github.com/Auth0
logo: auth0.png
related: single-sign-on, token-based-authentication, json-web-token, openid-connect, oauth, ws-federation, saml, identity-providers, sdk, enterprise-integration 
released: 2013
short_description: Auth0 is an Identity-as-a-Service provider. 
topic: auth0
url: https://auth0.com
---
Auth0 is an Identity-as-a-Service (IDaaS) provider. Auth0 provides customers with a Universal Identity Platform for their web, mobile, IoT, and internal applications.
