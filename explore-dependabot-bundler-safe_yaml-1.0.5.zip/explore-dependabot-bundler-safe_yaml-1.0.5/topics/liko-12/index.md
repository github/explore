---
display_name: LIKO-12
aliases: liko12
related: tic-80, pico-8, pixel-vision-8, basic8
short_description: LIKO-12 is an open source fantasy computer made using LÖVE.
topic: liko-12
created_by: Rami Sabbagh
github_url: https://github.com/RamiLego4Game/LIKO-12
url: https://ramilego4game.itch.io/liko12
logo: liko-12.png
---
LIKO-12 is an open source fantasy computer completely written in the Lua programming language where you can make, play and share tiny retro-looking games and programs.
