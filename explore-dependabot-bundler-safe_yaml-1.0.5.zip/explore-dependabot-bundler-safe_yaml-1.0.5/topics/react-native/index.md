---
aliases: react-native-app
created_by: Facebook
display_name: React Native
github_url: https://github.com/facebook/react-native
logo: react-native.png
related: reactjs
released: January 2015
short_description: React Native is a JavaScript mobile framework developed by Facebook.
topic: react-native
url: http://reactnative.com/
wikipedia_url: https://en.wikipedia.org/wiki/React_(JavaScript_library)#React_Native
---
React Native is a JavaScript mobile framework developed by Facebook. It allows developers to build Android and iOS mobile apps using JavaScript and reuse code across web and mobile applications.
