---
aliases: expressjs, express-js
created_by: TJ Holowaychuk
display_name: Express
github_url: https://github.com/expressjs
logo: express.png
released: November 16, 2010
short_description: Express is a minimal Node.js framework for web and mobile applications.
topic: express
url: https://expressjs.com/
wikipedia_url: https://en.wikipedia.org/wiki/Express.js
---
Express.js is a simple Node.js framework for single, multi-page, and hybrid web applications.
