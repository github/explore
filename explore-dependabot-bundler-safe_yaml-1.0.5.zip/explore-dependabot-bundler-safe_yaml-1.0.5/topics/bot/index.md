---
aliases: bots
display_name: Bot
short_description: A bot is an application that runs automated tasks over the Internet.
topic: bot
wikipedia_url: https://en.wikipedia.org/wiki/Internet_bot
---
A bot is an application that runs automated, usually repetitive tasks over the Internet.
