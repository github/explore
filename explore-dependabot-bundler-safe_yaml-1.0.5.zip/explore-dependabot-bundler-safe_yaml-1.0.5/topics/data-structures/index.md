---
aliases: data-structure
display_name: Data structures
short_description: Data structures are a way of organizing and storing data.
topic: data-structures
related: algorithm
wikipedia_url: https://en.wikipedia.org/wiki/Data_structure
---
A data structure is a particular way storing and organizing data in a computer for efficient access and modification. Data structures are designed for a specific purpose. Examples include arrays, linked lists, and classes.