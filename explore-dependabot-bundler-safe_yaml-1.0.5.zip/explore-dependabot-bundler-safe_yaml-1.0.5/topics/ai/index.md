---
aliases: artificial-intelligence, machine-intelligence
display_name: Artificial Intelligence
related: machine-learning, deep-learning, neural-network
short_description: Artificial intelligence is the ability of a computer or machine to perform tasks commonly associated with intelligent beings.
topic: ai
wikipedia_url: https://en.wikipedia.org/wiki/Artificial_intelligence
---
The branch of computer science dealing with the reproduction, or mimicking of human-level intelligence, self-awareness, knowledge, conscience, and thought in computer programs.
