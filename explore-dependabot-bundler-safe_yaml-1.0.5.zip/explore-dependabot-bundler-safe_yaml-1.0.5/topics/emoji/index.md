---
aliases: emojis, emoji-unicode, emoji-keyboard, emojipacks
created_by: Shigetaka Kurita
display_name: Emoji
released: '1999'
short_description: Emojis are graphic symbols that represent an emotion, object, or
  concept.
topic: emoji
wikipedia_url: https://en.wikipedia.org/wiki/Emoji
---
Emojis are a pictorial language used mainly in electronic messaging to express a variety of emotions, objects or ideas.
