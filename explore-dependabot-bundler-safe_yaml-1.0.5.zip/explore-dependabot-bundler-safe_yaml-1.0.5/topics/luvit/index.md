---
created_by: Tim Caswell
display_name: Luvit
logo: luvit.png
released: 2011
short_description: Asynchronous I/O for Lua.
topic: luvit
url: https://luvit.io
related: lua
github_url: https://github.com/luvit/luvit
---
Luvit is an asychronous I/O Lua runtime environment developed by Tim Caswell and contributors that implements Node.js APIs to Lua.
