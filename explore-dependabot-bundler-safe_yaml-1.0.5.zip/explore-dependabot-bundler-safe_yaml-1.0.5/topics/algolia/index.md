---
aliases: algoliasearch, algolia-search
related: instantsearch, instant-search
created_by: Nicolas Dessaigne, Julien Lemoine
display_name: Algolia
github_url: https://github.com/algolia/
logo: algolia.png
released: October 23, 2012
short_description: Algolia is a hosted search API for web and mobile applications.
topic: algolia
url: https://www.algolia.com/
wikipedia_url: https://en.wikipedia.org/wiki/Algolia
---
Algolia is a hosted API for building search into web and mobile applications, with typo-tolerance, fully configurable relevance, and other tools for making great search experiences.
