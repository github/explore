---
created_by: Vitalik Buterin
display_name: Ethereum
logo: ethereum.png
released: July 30, 2015
short_description: Ethereum is a distributed public blockchain network.
topic: ethereum
related: blockchain, cryptocurrency
url: https://www.ethereum.org/
github_url: https://github.com/ethereum
wikipedia_url: https://en.wikipedia.org/wiki/Ethereum
---
Ethereum is a decentralized platform that runs contract-based applications without any possibility of downtime, censorship, fraud or third-party interference. Ethereum blockchain focuses on running the code of any decentralized application.