---
aliases: sketch-plugin
created_by: Pieter Omvlee
display_name: Sketch
github_url: https://github.com/BohemianCoding
logo: sketch.png
released: September 7, 2010
short_description: Sketch is a vector graphics editor for Apple's macOS, used primarily for user interface and icon design.
topic: sketch
url: https://www.sketchapp.com/
wikipedia_url: https://en.wikipedia.org/wiki/Sketch_(application)
---
Sketch is a digital design toolkit built for designers, intended for editing vector graphics in macOS. It is used primarily for user interface and icon design.
