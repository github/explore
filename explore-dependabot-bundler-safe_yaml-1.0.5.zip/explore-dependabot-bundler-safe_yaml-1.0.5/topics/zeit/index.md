---
display_name: ZEIT
github_url: https://github.com/zeit
logo: zeit.png
short_description: A company that builds tools that make cloud computing as easy and accessible as mobile computing.
topic: zeit
url: https://zeit.co
---
ZEIT's mission is to make cloud computing as easy and accessible as mobile computing. It builds products for developers and designers, and those who aspire to become one.
