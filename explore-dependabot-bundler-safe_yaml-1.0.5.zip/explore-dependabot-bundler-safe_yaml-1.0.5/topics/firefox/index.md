---
aliases: mozilla-firefox,firefox-quantum,firefox-browser
related: mozilla,chrome,safari,edge,opera,browser,gecko,firefox-extension
created_by: Mozilla
display_name: Firefox
github_url: https://github.com/mozilla/gecko-dev
logo: firefox.png
released: September 23, 2002
short_description: Firefox is an open source web browser from Mozilla.
topic: firefox
url: https://www.mozilla.org/firefox
wikipedia_url: https://en.wikipedia.org/wiki/Firefox
---

Firefox is a free and open source web browser developed by Mozilla Foundation. First released in 2002 under the name Phoenix. It's available for most operating systems including Windows, macOS, Linux and most phones and tablets.
