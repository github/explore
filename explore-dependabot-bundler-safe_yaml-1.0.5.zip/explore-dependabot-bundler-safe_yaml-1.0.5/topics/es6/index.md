---
aliases: es6-javascript, es6-tutorial
created_by: Brendan Eich‎, ‎Ecma International
display_name: ES6
github_url: https://github.com/tc39
logo: es6.png
released: '1997'
short_description: ECMAScript 6 is the sixth release of the ECMAScript language.
topic: es6
url: http://www.ecma-international.org/
wikipedia_url: https://en.wikipedia.org/wiki/ECMAScript
---
ECMAScript is the standardization of script languages, including JavaScript. ECMA stands for the European Computer Manufacturer's Association.
