---
aliases: chrome-extensions
created_by: Google Inc.
display_name: Chrome extension
logo: chrome-extension.png
released: December 8, 2009
short_description: Google Chrome Extensions are add-ons that allow users to customize
  their Chrome web browser.
topic: chrome-extension
url: https://chrome.google.com/webstore/category/extensions
wikipedia_url: https://en.wikipedia.org/wiki/Google_Chrome_extension
---
Google Chrome Extensions are add-ons that allow users to customize their Chrome web browser. They are downloadable through the Chrome Web Store. Extensions are most often written in HTML, JavaScript, and CSS.
