---
topic: wordplate
created_by: Vincent Klaiber
display_name: WordPlate
github_url: https://github.com/wordplate
logo: wordplate.png
released: October 4, 2013
related: wordpress, composer, laravel, symfony, php
short_description: WordPlate is a modern WordPress stack built with Composer.
url: https://wordplate.github.io/
---
WordPlate is a modern WordPress stack. WordPlate uses WordPress as a framework that lets you install plugins and themes with Composer via WPackagist. WordPlate is built on top of Laravel and Symfony components.
