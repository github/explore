---
aliases: rails5, rails-application, ruby-on-rails, rails4, rubyonrails, rails-tutorial
created_by: David Heinemeier Hansson
display_name: Rails
github_url: https://github.com/rails
logo: rails.png
released: December 13 2005
short_description: Ruby on Rails (Rails) is a web application framework written in
  Ruby.
topic: rails
url: http://rubyonrails.org/
wikipedia_url: https://en.wikipedia.org/wiki/Ruby_on_Rails
---
Ruby on Rails (Rails) is a web application framework written in Ruby. It is meant to help simplify the building of complex websites.
