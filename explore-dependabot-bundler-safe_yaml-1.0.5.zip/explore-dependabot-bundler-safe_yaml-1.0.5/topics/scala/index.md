---
created_by: Martin Odersky
display_name: Scala
logo: scala.png
released: January 20, 2004
short_description: Scala is an object-oriented programming language.
topic: scala
url: http://www.scala-lang.org/
wikipedia_url: https://en.wikipedia.org/wiki/Scala_(programming_language)
---
Scala is a general-purpose programming language providing support for functional programming and a strong static type system. Designed to be concise, many of Scala's design decisions aimed to address criticisms of Java.
