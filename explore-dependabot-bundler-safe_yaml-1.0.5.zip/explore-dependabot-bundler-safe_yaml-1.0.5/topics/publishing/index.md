---
display_name: Publishing
short_description: Publishing is the dissemination of making information available to the general public through various mediums.
topic: publishing
wikipedia_url: https://en.wikipedia.org/wiki/Desktop_publishing
---
Publishing is the creation of documents using page layout skills on a personal computer primarily for print. Desktop publishing software can generate layouts and produce typographic quality text and images comparable to traditional typography and printing.
