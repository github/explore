---
created_by: World Wide Web Consortium
display_name: XML
released: 1996
short_description: XML is subset of SGML (Standard Generalized Markup Language) used to store and transport data.
topic: xml
related: css, html, rss, xhtml,web
url: https://www.w3.org/TR/xml/
wikipedia_url: https://en.wikipedia.org/wiki/XML
---
 XML stands for Extensible Markup Language and is a text-based markup language. It is designed to store and transport data, HTML is used to format and display the same data. It allows developers to create their own self-descriptive tags, or language, that suits their application.
