---
aliases: deploy-tool, deployment-manager
display_name: Deployment
short_description: Streamline your code deployment so you can focus on your product.
topic: deployment
wikipedia_url: https://en.wikipedia.org/wiki/Software_deployment
---
The general deployment process consists of several interrelated activities with possible transitions between them. These activities can occur at the producer side or at the consumer side or both.
