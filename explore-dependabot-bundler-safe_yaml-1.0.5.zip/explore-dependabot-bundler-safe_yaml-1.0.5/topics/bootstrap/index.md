---
aliases: bootstrap3, bootstrap4, bootstrap-4
created_by: Mark Otto, Jacob Thornton
display_name: Bootstrap
github_url: https://github.com/twbs
logo: bootstrap.png
released: August 19, 2011
short_description: Bootstrap is an HTML, CSS, and JavaScript framework.
topic: bootstrap
url: https://getbootstrap.com/
wikipedia_url: https://en.wikipedia.org/wiki/Bootstrap_(front-end_framework)
---
Bootstrap is a popular front-end framework that streamlines website design. It allows for the creation of easy and responsive web layouts.
