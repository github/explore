---
aliases: zshell
created_by: Paul Falstad
display_name: Zsh
github_url: https://github.com/zsh-users/zsh
related: shell
released: 1990
short_description: Zsh (Z shell) is a shell and command language interpreter.
topic: zsh
url: https://www.zsh.org
wikipedia_url: https://en.wikipedia.org/wiki/Z_shell
---
The Z shell (Zsh) is an extended Bourne shell with a large number of improvements and additional features.
