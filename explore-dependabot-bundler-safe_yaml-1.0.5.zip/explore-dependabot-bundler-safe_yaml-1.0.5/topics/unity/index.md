---
aliases: unity3d
created_by: Unity Technologies
display_name: Unity
github_url: https://github.com/Unity-Technologies
logo: unity.png
short_description: Unity is a game engine used to create 2D/3D video games, and simulations for computers, consoles, and mobile devices.
topic: unity
url: https://unity3d.com/
---
Unity is a game development platform used to build high-quality 3D/2D games that can deployed across mobile, desktop, VR/AR, consoles, or the web.
