---
created_by: Massimo Banzi
display_name: Arduino
github_url: https://github.com/arduino/
logo: arduino.png
released: '2003'
short_description: Arduino is an open source hardware and software company and maker
  community.
topic: arduino
url: https://www.arduino.cc/
wikipedia_url: https://en.wikipedia.org/wiki/Arduino
---
Arduino is an open source hardware and software company and maker community. Arduino started in the early 2000s. Popular with electronic makers, Arduino offers a lot of flexibility through an open source system.
