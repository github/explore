---
aliases: ticketing, helpdesk
display_name: Support
short_description: Get your team and customers the help they need.
topic: support
wikipedia_url: https://en.wikipedia.org/wiki/Help_desk
---
A help desk is a resource intended to provide the customer or end user with information and support related to a company's or institution's products and services.
