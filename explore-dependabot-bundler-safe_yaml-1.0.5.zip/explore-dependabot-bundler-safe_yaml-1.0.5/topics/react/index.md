---
aliases: reactjs, react-js
created_by: Jordan Walke
display_name: React
github_url: https://github.com/facebook/react
logo: react.png
related: vue, angular, react-native
released: March 2013
short_description: React is an open source JavaScript library used for designing user
  interfaces.
topic: react
url: https://reactjs.org/
wikipedia_url: https://en.wikipedia.org/wiki/React_(JavaScript_library)
---
React (also known as React.js or ReactJS) is a JavaScript library that makes developing interactive user interfaces simple.
