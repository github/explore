---
aliases: game-engine-framework, game-engine-development, game-engines
display_name: Game engine
short_description: A game engine is a software framework used to develop and create
  video games.
topic: game-engine
wikipedia_url: https://en.wikipedia.org/wiki/Game_engine
---
Game engines are software frameworks for game development. Game engines do the heavy lifting for developers so they can focus on other aspects of game development.
