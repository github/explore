---
aliases: ksp, kerbal, kerbal-space, kerbalspaceprogram
created_by: Squad
display_name: Kerbal Space Program
logo: kerbal-space-program.png
released: April 27, 2015
short_description: Kerbal Space Program is space flight simulation game.
topic: kerbal-space-program
url: https://kerbalspaceprogram.com/
wikipedia_url: https://en.wikipedia.org/wiki/Kerbal_Space_Program
---
Published by Squad, Kerbal Space Program is a game in which players direct a space program. The game features a realistic orbital physics engine, allowing for various real-life orbital maneuvers such as Hohmann transfer orbits and bi-elliptic transfer orbits.
