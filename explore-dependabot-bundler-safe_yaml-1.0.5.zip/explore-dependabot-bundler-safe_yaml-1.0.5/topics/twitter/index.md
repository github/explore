---
display_name: Twitter
github_url: https://github.com/twitter
logo: twitter.png
created_by: Jack Dorsey, Noah Glass, Biz Stone, Evan Williams
released: March 21, 2006
short_description: Twitter is an online news and social networking service where users post and interact with messages, known as “Tweets”.
topic: twitter
url: https://www.twitter.com
wikipedia_url: https://en.wikipedia.org/wiki/Twitter
---
Twitter is an online news and social networking service where users post and interact with messages, known as “Tweets.” These messages were originally restricted to 140 characters, but in November 2017, the limit was doubled to 280 characters for all languages except Japanese, Korean, and Chinese.
