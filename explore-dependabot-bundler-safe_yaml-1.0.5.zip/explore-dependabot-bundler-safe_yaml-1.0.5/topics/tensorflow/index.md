---
aliases: tensorflow-tutorials, tensorflow-experiments, tensorflow-models, tensorflow-examples,
  tensorflow-1-0, tensorflow-tutorial
created_by: Google Brain Team
display_name: Tensorflow
github_url: https://github.com/tensorflow
logo: tensorflow.png
released: November 9, 2015
short_description: TensorFlow is an open source software library for numerical computation.
topic: tensorflow
url: https://www.tensorflow.org/
wikipedia_url: https://en.wikipedia.org/wiki/TensorFlow
---
TensorFlow is an open source library that was created by Google. It is used to design, build, and train deep learning models.
