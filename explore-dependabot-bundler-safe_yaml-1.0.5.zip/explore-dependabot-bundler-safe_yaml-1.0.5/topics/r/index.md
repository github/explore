---
created_by: Ross Ihaka, Robert Gentleman
display_name: R
logo: r.png
related: language
released: August 1993
short_description: R is a free programming language and software environment for statistical
  computing and graphics.
topic: r
url: https://www.r-project.org/
wikipedia_url: https://en.wikipedia.org/wiki/R_(programming_language)
---
R is a free programming language and software environment for statistical computing and graphics. R has a wide variety of statistical linear and non-linear modeling and provides numerous graphical techniques.
