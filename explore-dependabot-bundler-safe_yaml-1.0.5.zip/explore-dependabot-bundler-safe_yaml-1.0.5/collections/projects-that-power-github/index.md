---
items:
 - codahale/bcrypt-ruby
 - zeroclipboard/zeroclipboard
 - github/resque
 - leereilly/swot
 - mysql/mysql-server
 - Leaflet/Leaflet
 - facebook/flow
 - chaijs/chai
 - primer/css
 - primer/octicons
 - eslint/eslint
 - mochajs/mocha
 - lerna/lerna
 - github/linguist
 - elastic/elasticsearch
 - rails/rails
 - antirez/redis
 - rails/sprockets
 - libgit2/libgit2
 - libgit2/rugged
 - jch/html-pipeline
 - github/gemoji
 - jekyll/jekyll
 - octokit/octokit.rb
 - hubotio/hubot
 - d3/d3
 - ajaxorg/ace
 - brianmario/charlock_holmes
 - puppetlabs/puppet
 - nanoc/nanoc
 - github/hoosegow
 - gjtorikian/html-proofer
 - babel/babel
 - stylelint/stylelint
display_name: Projects that power GitHub
created_by: leereilly
image: projects-that-power-github.png
---
Some of the great open source projects that GitHub uses to power its infrastructure
