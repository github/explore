---
items:
 - github/SoftU2F
 - awslabs/git-secrets
display_name: Keeping user data safe
created_by: ptoomey3
---
Reducing risk in your software projects doesn’t have to be a full time job. Explore some small security steps that make a big difference.
