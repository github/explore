---
items:
 - simbody/simbody
 - cms-sw/cmssw
 - ComputationalRadiationPhysics/picongpu
 - psas/av3-fc
 - astropy/astropy
 - dfm/emcee
 - cyverse/atmosphere
 - dib-lab/khmer
 - sympy/sympy
 - spack/spack
 - ipython/ipython
 - ropensci/rplos
 - LaurentRDC/scikit-ued
display_name: Software in science
image: software-in-science.png
---
Scientists around the world are working together to solve some of the biggest questions in research.
