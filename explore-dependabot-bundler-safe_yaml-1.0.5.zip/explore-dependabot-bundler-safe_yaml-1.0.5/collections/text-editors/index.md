---
items:
 - adobe/brackets
 - limetext/lime
 - textmate/textmate
 - neovim/neovim
 - sharelatex/sharelatex
 - slap-editor/slap
 - thomaswilburn/Caret
 - Komodo/KomodoEdit
 - leo-editor/leo-editor
 - syl20bnr/spacemacs
 - SpaceVim/SpaceVim
 - alm-tools/alm
 - atom/atom
 - LightTable/LightTable
 - zedapp/zed
 - Microsoft/vscode
 - zyedidia/micro
display_name: Text editors
created_by: leereilly
image: text-editors.png
---
The text editor is a sacred application for developers. Here's a showcase of some amazingly awesome open source editors.
