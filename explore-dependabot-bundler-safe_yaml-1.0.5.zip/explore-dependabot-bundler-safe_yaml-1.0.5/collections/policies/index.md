---
items:
 - github/balanced-employee-ip-agreement
 - github/site-policy
 - hackdaymanifesto/hackdaymanifesto.github.com
 - BetaNYC/Bike-Share-Data-Best-Practices
 - project-open-data/project-open-data.github.io
 - usds/playbook
 - catalyzeio/policies
 - 18F/open-source-policy
 - WhiteHouse/fitara
 - GSA/https
 - CommerceGov/Policies-and-Guidance
 - github/site-policy
 - Medium/medium-policy
 - Automattic/legalmattic
 - divegeek/uscode
 - seriesseed/equity
display_name: Policies
created_by: benbalter
---
From federal governments to corporations to student clubs, groups of all sizes are using GitHub to share, discuss, and improve laws.  *Ask not what the repository can do for you...*
