---
items:
 - godotengine/godot
 - turbulenz/turbulenz_engine
 - GarageGames/Torque3D
 - GarageGames/Torque2D
 - spring/spring
 - cocos2d/cocos2d-x
 - Gamua/Starling-Framework
 - gameplay3d/GamePlay
 - jMonkeyEngine/jmonkeyengine
 - SFTtech/openage
 - MonoGame/MonoGame
 - libgdx/libgdx
 - superpowers/superpowers-core
 - AtomicGameEngine/AtomicGameEngine
 - 4ian/GDevelop
 - CRYTEK/CRYENGINE
 - urho3d/Urho3D
 - benoit-dumas/OpenRTS
 - BearishSun/BansheeEngine
 - photonstorm/phaser
 - melonjs/melonJS
 - BabylonJS/Babylon.js
 - WhitestormJS/whs.js
 - wellcaffeinated/PhysicsJS
 - playcanvas/engine
 - cocos2d/cocos2d-html5
 - craftyjs/Crafty
 - pixijs/pixi.js
 - renpy/renpy
 - OpenRA/OpenRA
 - OpenRCT2/OpenRCT2
 - xenko3d/xenko
 - lance-gg/lance
display_name: Game Engines
created_by: leereilly
---
Frameworks for building games across multiple platforms.
