---
items:
 - ovity/octotree
 - mike-north/chrome-github-boxcutter
 - muan/github-dashboard
 - muan/github-gmail
 - thieman/github-selfies
 - Yatser/prettypullrequests
 - sanemat/do-not-merge-wip-for-github
 - jasonlong/isometric-contributions
 - ForbesLindesay/github-real-names
 - benbalter/github-mention-highlighter
 - sindresorhus/notifier-for-github
 - OctoLinker/OctoLinker
 - ProLoser/Github-Omnibox
 - Justineo/github-hovercard
 - panzerdp/clipboardy
 - kamranahmedse/githunt
 - harshjv/github-repo-size
 - sindresorhus/refined-github
 - bitoiu/markwrap
 - bitoiu/github-red-alert
 - Kibibit/achievibit
 - marpo60/github-compare-tags
 - cheshire137/hubnav
 - ryanflorence/github-plusone-extension
 - Mottie/GitHub-userscripts
 - rgehan/octolenses-browser-extension
 - xxhomey19/github-file-icon
display_name: GitHub Browser Extensions
created_by: leereilly
---
Some useful and fun browser extensions to personalize your GitHub browser experience.
