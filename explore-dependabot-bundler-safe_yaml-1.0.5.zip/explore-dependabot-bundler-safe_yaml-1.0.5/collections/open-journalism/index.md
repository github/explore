---
items:
 - fivethirtyeight/data
 - datadesk/notebooks
 - NYTimes/objective-c-style-guide
 - newsapps/beeswithmachineguns
 - voxmedia/meme
 - propublica/guides
 - censusreporter/censusreporter
 - nprapps/app-template
 - TimeMagazine/babynames
 - guardian/frontend
 - dukechronicle/chronline
 - BloombergMedia/whatiscode
 - times/cardkit
display_name: Open journalism
created_by: benbalter
---
See how publications and data-driven journalists use open source to power their newsroom and ensure information is reported fairly and accurately.
