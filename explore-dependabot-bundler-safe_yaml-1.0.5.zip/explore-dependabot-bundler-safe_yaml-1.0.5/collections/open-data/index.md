---
items:
 - GSA/data
 - unitedstates/congress-legislators
 - Chicago/food-inspections-evaluation
 - OpenExoplanetCatalogue/open_exoplanet_catalogue
 - cernopendata/opendata.cern.ch
 - openaddresses/openaddresses
 - APIs-guru/openapi-directory
display_name: Open data
created_by: benbalter
---
Examples of using GitHub to store, publish, and collaborate on open, machine-readable datasets
