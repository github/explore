---
items:
 - tdsmith/github-snooze-button
 - octobox/octobox
 - semantic-release/semantic-release
 - Netflix/hubcommander
 - github-changelog-generator/github-changelog-generator
 - servo/homu
 - github-modules/ghwd
 - jlord/offline-issues
 - greenkeeperio/greenkeeper
 - probot/stale
 - servo/highfive
 - sagesharp/foss-heartbeat
 - hzoo/contributors-on-github
 - pengwynn/flint
 - WeAllJS/weallbehave
 - WeAllJS/weallcontribute
 - danger/danger
 - icecrime/poule
 - probot/settings
 - cla-assistant/cla-assistant
 - zeke/package-json-to-readme
 - hakirisec/hakiri_toolbelt
 - standard/standard
 - lerna/lerna
 - marmelab/sedy
 - badges/shields
 - bitrise-io/bitrise
display_name: Tools for Open Source
created_by: mozzadrella
image: tools-for-open-source.png
---
Software to make running your open source project a little bit easier.
